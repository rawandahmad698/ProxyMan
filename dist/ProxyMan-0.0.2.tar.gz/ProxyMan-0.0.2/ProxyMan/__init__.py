"""
ProxyMan
"""
__version__ = "0.0.1"
__author__ = 'Rawand Ahmed Shaswar'


from .proxyman import ProxyMan, Filter, AuthType
